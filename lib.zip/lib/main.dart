import 'package:flutter/material.dart';
import 'package:weddingorganizer/views/screens/auth/signup.dart';

void main() {
  runApp(const MainApp());
}

class MainApp extends StatelessWidget {
  const MainApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        Signup.pageroute: (ctx) => const Signup(),
      },
      initialRoute: Signup.pageroute,
    );
  }
}
