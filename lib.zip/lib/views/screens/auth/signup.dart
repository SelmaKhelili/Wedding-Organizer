import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class Signup extends StatefulWidget {
  static const String pageroute = '/signup';
  const Signup({super.key});

  @override 
  State<Signup> createState() => _SignupState();
}

class _SignupState extends State<Signup> {
  String role = 'None';
  bool _isAgreed = false;
  final _emailController = TextEditingController();
  final _passwordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();
  Map<String, Map<String, String>> users = {};
  final GlobalKey<FormState> _formkey = GlobalKey<FormState>();

  void _register() {
    if (_formkey.currentState?.validate() ?? false) {
      String email = _emailController.text;
      String password = _passwordController.text;
      String confirmPassword = _confirmPasswordController.text;

      if (password != confirmPassword) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(
          content: Text('Passwords do not match!'),
          backgroundColor: Colors.red,
        ));
        return;
      }
}
}
 @override
Widget build(BuildContext context) {
  return Scaffold(
    body: SingleChildScrollView(
      child: Center(
        child: Stack(
          children: [
            Column(
              mainAxisAlignment: MainAxisAlignment.start,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.only(
                    top: 30.0,    // Top padding of 30
                    bottom: 20.0, // Bottom padding of 20
                    left: 40.0,   // Left padding of 10
                  ),
                  child: Text(
                    'Hello!',
                    style: GoogleFonts.jomhuria(
                      fontSize: 50,
                      fontWeight: FontWeight.w900,
                      color: const Color.fromARGB(255, 234, 186, 210),
                    ),
                  ),
                ),
                Container(
                  decoration: const BoxDecoration(
                    color: Color.fromARGB(255, 249, 234, 242),
                    borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(16.0),
                      topRight: Radius.circular(16.0),
                    ),
                  ),
                  child: DefaultTextStyle(
                    style: GoogleFonts.raleway(
                      color: const Color.fromARGB(255, 255, 255, 255),
                    ),
                    child: 
                  Expanded(
                    child:
                      Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(20.0),
                          child: Text(
                            'Create a new account',
                            style: GoogleFonts.raleway(
                              fontSize: 25,
                              color: const Color.fromARGB(255, 181, 88, 139),
                            ),
                          ),
                        ),
                        // Add Expanded here to make the column take available space
                        Expanded(
                          child: Container(
                            decoration: const BoxDecoration(
                              color: Color.fromRGBO(234, 186, 210, 1),
                              borderRadius: BorderRadius.only(
                                topLeft: Radius.circular(16.0),
                                topRight: Radius.circular(16.0),
                              ),
                            ),
                            child: Column(
                              children: [
                                Padding(
                                  padding: const EdgeInsets.only(
                                    left: 16.0,
                                    right: 16.0,
                                  ),
                                  child: Form(
                                    key: _formkey,
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        const SizedBox(height: 15),
                                        const Text('    Email Address'),
                                        const SizedBox(height: 2),
                                        TextFormField(
                                          controller: _emailController,
                                          validator: (email) {
                                            if (email == null || email.isEmpty) {
                                              return 'Please enter your email';
                                            }
                                            final emailRegex =
                                                RegExp(r'^[^@]+@[^@]+\.[^@]+$');
                                            if (!emailRegex.hasMatch(email)) {
                                              return 'Please enter a valid email';
                                            }
                                            return null;
                                          },
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                            ),
                                            hintText: 'Enter Email ID',
                                            hintStyle: GoogleFonts.poppins(
                                              color: const Color.fromARGB(
                                                  255, 123, 123, 123),
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    255, 181, 88, 139),
                                                width: 2.0,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        const Text('    Password'),
                                        const SizedBox(height: 2),
                                        TextFormField(
                                          controller: _passwordController,
                                          validator: (password) {
                                            if (password == null ||
                                                password.isEmpty) {
                                              return 'Please enter your password';
                                            }
                                            if (password.length < 8) {
                                              return 'Password must be at least 8 characters';
                                            }
                                            return null;
                                          },
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                            ),
                                            hintText: 'Enter Password',
                                            hintStyle: GoogleFonts.poppins(
                                              color: const Color.fromARGB(
                                                  255, 103, 102, 103),
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    255, 181, 88, 139),
                                                width: 2.0,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        const Text('    Confirm Password'),
                                        const SizedBox(height: 2),
                                        TextFormField(
                                          controller: _confirmPasswordController,
                                          validator: (password) {
                                            if (password == null ||
                                                password.isEmpty) {
                                              return 'Please enter your password';
                                            }
                                            if (password !=
                                                _passwordController.text) {
                                              return 'Passwords do not match';
                                            }
                                            return null;
                                          },
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                            ),
                                            hintText: 'Confirm Password',
                                            hintStyle: GoogleFonts.poppins(
                                              color: const Color.fromARGB(
                                                  255, 103, 102, 103),
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(25.0),
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    255, 181, 88, 139),
                                                width: 2.0,
                                              ),
                                            ),
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        const Text(
                                            '    Are you a vendor or a venue owner?'),
                                        const SizedBox(height: 2),
                                        DropdownButtonFormField<String>(
                                          value: role,
                                          decoration: InputDecoration(
                                            border: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                            ),
                                            filled: true,
                                            fillColor: Colors.white,
                                            focusedBorder: OutlineInputBorder(
                                              borderRadius:
                                                  BorderRadius.circular(20.0),
                                              borderSide: const BorderSide(
                                                color: Color.fromARGB(
                                                    255, 181, 88, 139),
                                                width: 2.0,
                                              ),
                                            ),
                                          ),
                                          items: [
                                            DropdownMenuItem<String>(
                                              value: 'None',
                                              child: SizedBox(
                                                width: 100,
                                                child: const Text(
                                                  'None',
                                                  style: TextStyle(
                                                      color: Color.fromARGB(
                                                          255, 103, 102, 103)),
                                                ),
                                              ),
                                            ),
                                            DropdownMenuItem<String>(
                                              value: 'Vendor',
                                              child: SizedBox(
                                                width: 100,
                                                child: const Text(
                                                  'Vendor',
                                                  style: TextStyle(
                                                      color: Color.fromARGB(
                                                          255, 103, 102, 103)),
                                                ),
                                              ),
                                            ),
                                            DropdownMenuItem<String>(
                                              value: 'Venue',
                                              child: SizedBox(
                                                width: 100,
                                                child: const Text(
                                                  'Venue Owner',
                                                  style: TextStyle(
                                                      color: Color.fromARGB(
                                                          255, 103, 102, 103)),
                                                ),
                                              ),
                                            ),
                                          ],
                                          onChanged: (value) {
                                            setState(() {
                                              role = value!;
                                            });
                                          },
                                          style: const TextStyle(
                                            color: Color.fromARGB(
                                                255, 105, 105, 105),
                                          ),
                                        ),
                                        Row(
                                          children: [
                                            Padding(
                                              padding: const EdgeInsets.only(
                                                  left: 16),
                                              child: Checkbox(
                                                value: _isAgreed ?? false,
                                                onChanged: (bool? newValue) {
                                                  setState(() {
                                                    _isAgreed = newValue ??
                                                        false;
                                                  });
                                                },
                                                side: const BorderSide(
                                                  color: Colors.white,
                                                  width: 2.0,
                                                ),
                                                checkColor: Colors.white,
                                                activeColor: const Color.fromARGB(
                                                    255, 181, 88, 139),
                                              ),
                                            ),
                                            const Text(
                                              'I Agree to the Terms and Conditions',
                                              style: TextStyle(
                                                fontSize: 12,
                                              ),
                                            )
                                          ],
                                        ),
                                        const SizedBox(height: 20),
                                        Padding(
                                          padding: const EdgeInsets.only(
                                            left: 16.0,
                                            right: 16.0,
                                          ),
                                          child: SizedBox(
                                            width: double.infinity,
                                            child: ElevatedButton(
                                              onPressed: () {
                                                _submitForm();
                                              },
                                              style: ElevatedButton.styleFrom(
                                                shape: RoundedRectangleBorder(
                                                  borderRadius:
                                                      BorderRadius.circular(25),
                                                ),
                                                padding: const EdgeInsets.all(15),
                                              ),
                                              child: Text(
                                                'Create Account',
                                                style: GoogleFonts.poppins(
                                                    fontWeight:
                                                        FontWeight.bold),
                                              ),
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  )
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    ),
  );
}

}
